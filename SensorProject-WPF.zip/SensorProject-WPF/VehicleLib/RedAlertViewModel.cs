﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VehicleLib
{
    public class RedAlertViewModel
    {
        public RedAlert RedAlert { get; set; }
        public List<Vehicle> Vehicles { get; set; }
    }
}
